module Control.Concurrent.STM.Extras (
  module Control.Concurrent.STM.Extras.Stream
  ) where

import Control.Concurrent.STM.Extras.Stream
